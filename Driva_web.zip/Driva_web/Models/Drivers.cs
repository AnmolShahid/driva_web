﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Models
{
    public class Drivers
    {

       public String id { get; set; }
       public String username { get; set; }
       public String email { get; set; }
        public String phone { get; set; }
        public int role { get; set; }
        public int status { get; set; }
        public int tag { get; set; }

        

    }
}
