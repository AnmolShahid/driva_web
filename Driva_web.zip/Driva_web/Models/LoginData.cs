﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Models
{

    public class LoginData
    {
        public string TimestampUtc { get; set; }

        [Required(ErrorMessage = "Please Enter Email")]
        public string username { get; set; }
        [Required(ErrorMessage = "Please Enter Your Password")] 
        public string password { get; set; }

    }
}
