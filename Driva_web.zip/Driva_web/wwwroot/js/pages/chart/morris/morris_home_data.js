jQuery(document).ready(function() {
	'use strict';

    var months = ["January", "Februry", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    Morris.Line({
        element: 'morris-bar-chart',
        data: [{
            m: '2020-01-01',
            a: 270
        }, {
                m: '2020-01-02',
            a: 54
        }, {
                m: '2020-01-03',
            a: 243
        }, {
                m: '2020-01-04',
            a: 206
        }, {
                m: '2020-01-05',
            a: 161
        }, {
                m: '2020-01-06',
            a: 187,
            
        }, {
                m: '2020-01-07',
            a: 210,
            
        }, {
                m: '2020-01-08',
            a: 204,
            
        }, {
                m: '2020-01-09',
            a: 224
        }, {
                m: '2020-01-10',
            a: 301
        }, {
                m: '2020-01-11',
            a: 262
        }, {
                m: '2020-01-12',
            a: 199
        },],
        xkey: 'm',
        ykeys: ['a'],
        labels: ['Total Earnings'],
        pointSize: 3,
        fillOpacity: 0,
        pointStrokeColors: ['#a879fd'],
        behaveLikeLine: true,
        gridLineColor: '#e0e0e0',
        lineWidth: 2,
        hideHover: 'auto',
        lineColors: ['#a879fd'],
        resize: true,
        xLabelAngle: 45,
   /*     xLabelFormat: function (x) { // <--- x.getMonth() returns valid index
            var month = months[x.getMonth()];
            return month;
        },
        dateFormat: function (x) {
            var month = months[new Date(x).getMonth()];
            return month;
        },*/
    });
	Morris.Line({
        element: 'line_chart',
        data: [{
            period: '2012',
            iphone: 450,
            
        },{
            period: '2013',
            iphone: 1340,
            
        },{
            period: '2014',
            iphone: 470,
           
        },{
            period: '2015',
            iphone: 1780,
            
        }, {
            period: '2016',
            iphone: 1230,
           
        }, {
            period: '2017',
            iphone: 780,
            
        }, {
            period: '2018',
            iphone: 820,
            
        }, {
            period: '2019',
            iphone: 1920,
            
        }, {
            period: '2020',
            iphone: 900,
            
        },
        {
            period: '2021',
            iphone: 2030,
            
        }
    ],
    xkey: 'period',
    ykeys: ['iphone'],
        labels: ['Total Earnings'],
    pointSize: 3,
    fillOpacity: 0,
    pointStrokeColors: ['#a879fd'],
    behaveLikeLine: true,
    gridLineColor: '#e0e0e0',
    lineWidth: 2,
    hideHover: 'auto',
    lineColors: ['#a879fd'],
    resize: true
    });
	
});

Morris.Bar({
	element: "area_line_chart",
	behaveLikeLine: true,
	data: [
        { w: '2021-01-01', x: 2, y: 10 },
        { w: '2021-01-02', x: 5, y: 150 },
        { w: '2021-01-03', x: 1, y: 50 },
        { w: '2021-01-04', x: 12, y: 102 },
        { w: '2021-01-05', x: 20, y: 302 },
        { w: '2021-01-06', x: 39, y: 167 },
        { w: '2021-01-07', x: 20, y: 119 }
	       ],
	       xkey: 'w',
	       ykeys: ['x', 'y'],
    labels: ['Customers', 'Income'],

    xLabelFormat: function (d) {
        return ("0" + d.getDate()).slice(-2) + '-' + ("0" + (d.getMonth() + 1)).slice(-2) + '-' + d.getFullYear();
    },
	       pointSize: 0,

	       lineWidth: 0,
	       resize: true,
	       fillOpacity: 0.8,
	       behaveLikeLine: true,
	       gridLineColor: '#e0e0e0',
	       hideHover: 'auto',
	       lineColors: [ '#20B2AA', '#6C96D2']
});


