/**
 *  Document   : editable_table_data.js
 *  Author     : Redstartheme
 *  Description: script for editable table data
 *
 **/

 $('#mainTable').editableTableWidget();