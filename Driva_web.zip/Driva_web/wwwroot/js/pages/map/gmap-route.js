/**
 *  Document   : google-maps-data.js
 *  Author     : Redstartheme
 *  Description: Google map data script
 *
 **/

var MapsGoogle = function() {
    function initMap() {
        const myLatLngPickup = { lat: 32.1049027, lng: 74.2137137 };
        const myLatLngDestination = { lat: 31.5298677, lng: 74.2591935 };

        const map = new google.maps.Map(document.getElementById("gmap_routes"), {
            zoom: 8,
            center: myLatLngPickup,
           
        });

        const contentStringPickup =
            '<div id="content">' +
            '<div id="siteNotice">' +
            "</div>" +
            '<h1 id="firstHeading" class="firstHeading">Pickup Location</h1>' +
            '<div id="bodyContent">' +
            "<p>Plot 419 A, Block- A Block A G Magnolia Park, Gujranwala, Punjab, Pakistan</p>"+
            "</div>" +
            "</div>";

        const contentStringDes =
            '<div id="content">' +
            '<div id="siteNotice">' +
            "</div>" +
            '<h1 id="firstHeading" class="firstHeading">Destination Location</h1>' +
            '<div id="bodyContent">' +
            "<p>Lahore-Islamabad Motorway</p>" +
            "</div>" +
            "</div>";

        const infowindowPickup = new google.maps.InfoWindow({
            content: contentStringPickup,
        });

        const infowindowDes = new google.maps.InfoWindow({
            content: contentStringDes,
        });
       
 


       const pickupMarker =  new google.maps.Marker({
            position: myLatLngPickup,
            map,
            title: "Plot 419 A, Block- A Block A G Magnolia Park, Gujranwala, Punjab, Pakistan",
        });
        const desMarker = new google.maps.Marker({
            position: myLatLngDestination,
            map,
            title: "Lahore-Islamabad Motorway",
        });


       
        const flightPlanCoordinates = [
            myLatLngPickup,
            myLatLngDestination,
            
        ];
        const flightPath = new google.maps.Polyline({
            path: flightPlanCoordinates,
            geodesic: true,
            strokeColor: "#FF0000",
            strokeOpacity: 1.0,
            strokeWeight: 2,
        });
        flightPath.setMap(map);

        pickupMarker.addListener("click", () => {
            infowindowPickup.open(map, marker);
        });

        desMarker.addListener("click", () => {
            infowindowDes.open(map, marker);
        });
    }


    var l = function () {
            var o = new GMaps({
                div: "#gmap_routes",
                lat: 23.0128440,
                lng: 72.5289980
            });
            $(document).on("click","#routes_start",function(t) { 
                t.preventDefault(), App.scrollTo($(this), 400), o.travelRoute({
                    origin: [23.0128440, 72.5289980],
                    destination: [23.0048648, 72.5013820],
                    travelMode: "driving",
                    step: function(t) {
                        $("#routes_instructions").append("<li>" + t.instructions + "</li>"), $("#routes_instructions li:eq(" + t.step_number + ")").delay(800 * t.step_number).fadeIn(500, function() {
                            o.setCenter(t.end_location.lat(), t.end_location.lng()), o.drawPolyline({
                                path: t.path,
                                strokeColor: "#131540",
                                strokeOpacity: .6,
                                strokeWeight: 6
                            })
                        })
                    }
                })
            })
    };


    return {
        init: function() {
            initMap()
        }
    }
}();
jQuery(document).ready(function() {
	'use strict';
    MapsGoogle.init()
});