﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Controllers
{
    public class PassengerController : Controller
    {
        public IActionResult AllPassenger()
        {
            return View();
        }

        public IActionResult passengerDetail()
        {
            return View();
        }

    }
}
