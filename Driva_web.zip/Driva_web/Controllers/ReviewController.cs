﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Controllers
{
    public class ReviewController : Controller
    {
        public IActionResult Review()
        {
            return View();
        }
    }
}
