﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Controllers
{
    public class VechicleController : Controller
    {
        public IActionResult AddVehicle()
        {
            return View();
        }
        public IActionResult AllVehicle()
        {
            return View();
        }
        public IActionResult EditVehicle()
        {
            return View();
        }
    }
}
