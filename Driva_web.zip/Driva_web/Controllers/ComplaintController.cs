﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Controllers
{
    public class ComplaintController : Controller
    {
        public IActionResult Complaint()
        {
            return View();
        }
    }
}
