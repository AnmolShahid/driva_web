﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Controllers
{
    public class TripController : Controller
    {
       

       public IActionResult ActiveTrip()
        {
            return View();
        }

        public IActionResult CompleteTrip()
        {
            return View();
        }

        public IActionResult BookedTrip()
        {
            return View();
        }

        public IActionResult TripRouteMap()
        {
            return View();
        }

        public IActionResult EditTrip()
        {
            return View();
        }

    }
}
