﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Controllers
{
    public class PaymentController : Controller
    {
        public IActionResult AllPayment()
        {
            return View();
        }
    }
}
