﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FireSharp.Config;
using FireSharp.Interfaces;
using Driva_web.Models;
using FireSharp.Response;

namespace Driva_web.Controllers
{
    public class DriverController : Controller
    {

        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "st0pUX7mfR2FEOIFzTMN8oVcX7dRbeopBWinPQDR",
            BasePath = "https://driva-app-20cb9-default-rtdb.firebaseio.com/",
        };

        IFirebaseClient client;


        public IActionResult AddDriver()
        {
            return View();
        }

        public IActionResult AllDriver()
        {
            return View();
        }

        public IActionResult DriverPayment()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Drivers drivers)
        {
            try
            {
                AddDriverToFirebase(drivers);
                ModelState.AddModelError(String.Empty, "Added Successfully");
            }
            catch (Exception e)
            {

            }
            return View();
        }

        private void AddDriverToFirebase(Drivers drivers)
        {
            client = new FireSharp.FirebaseClient(config);
            var data = drivers;
            PushResponse response = client.Push("users/", data);
            data.id = response.Result.name;
            SetResponse setResponse = client.Set("users" + data.id, data);



        }
    }
}
