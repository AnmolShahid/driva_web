﻿using Driva_web.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driva_web.Controllers
{
    public class AuthController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Submit(LoginData loginData)
        {
            if (loginData.username == "admin@driva.com" && loginData.password == "admin1234")
            {
                return View("Submit");
            }
            else
            {
                return View("Index");
            }

            
        }


    }


}
